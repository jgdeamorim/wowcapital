#!/usr/bin/env python3
"""
Teste de Endpoints Kraken (Futures Demo)
Verifica conectividade e operações básicas com a API Kraken Futures (sandbox)

IMPORTANTE: APENAS TESTNET/SANDBOX!

Autor: WOW Capital Trading System
Data: 2024-09-16 (atualizado para Futures API)
"""

import sys
import os
import time
import hmac
import hashlib
import base64
import requests
from typing import Dict, Any, Optional
import json
import logging
import argparse
from urllib.parse import urlencode

# Add backend to path
sys.path.insert(0, os.path.join(os.path.dirname(__file__), '..', '..', '..'))

from tests.integration.exchanges.credentials_manager import CredentialsManager

FUTURES_LIVE_BASE = "https://futures.kraken.com/derivatives/api/v3"
FUTURES_DEMO_BASE = "https://demo-futures.kraken.com/derivatives/api/v3"
FUTURES_VIP_BASE = "https://vip.futures.kraken.com/derivatives/api/v3"


class KrakenAPITester:
    """Testador da API Futures da Kraken"""

    def __init__(self, credentials_manager: CredentialsManager):
        self.cred_manager = credentials_manager
        self.credentials = credentials_manager.load_credentials()

        if not self.credentials.kraken:
            raise ValueError("Credenciais Kraken não disponíveis")

        env = (self.credentials.kraken.environment or "sandbox").lower()
        custom_base = os.getenv("KRAKEN_FUTURES_BASE_URL")
        if custom_base:
            self.base_url = custom_base.rstrip('/')
        elif env in {"sandbox", "demo", "futures_demo", "test", "testnet"}:
            self.base_url = FUTURES_DEMO_BASE
        elif env in {"sandbox_vip", "futures_vip", "vip"}:
            self.base_url = FUTURES_VIP_BASE
        elif env in {"live", "spot"}:
            # fallback para API spot (não recomendado neste tester)
            self.base_url = "https://api.kraken.com/0"
        else:
            self.base_url = FUTURES_LIVE_BASE

        self.api_key = self.credentials.kraken.api_key
        self.api_secret = self.credentials.kraken.api_secret
        try:
            self._api_secret_bytes = base64.b64decode(self.api_secret)
        except Exception as exc:  # pragma: no cover - configuração inválida
            raise ValueError("KRAKEN_PRIVATE_KEY deve estar em Base64") from exc

        self.logger = logging.getLogger(__name__)

    def _make_public_request(self, endpoint: str, params: Optional[Dict[str, Any]] = None) -> Dict[str, Any]:
        """Faz requisição pública para Kraken Futures"""

        url = f"{self.base_url.rstrip('/')}/{endpoint.lstrip('/')}"
        params = params or {}

        try:
            response = requests.get(url, params=params, timeout=10)
            response.raise_for_status()
            return response.json()

        except requests.exceptions.RequestException as e:
            self.logger.error(f"Erro na requisição pública {endpoint}: {str(e)}")
            raise

    def _compute_signature(self, endpoint: str, nonce: str, query_params: Dict[str, Any]) -> str:
        """Calcula a assinatura para a API Kraken Futures v3."""
        
        query_string = urlencode(query_params)
        
        # O path para assinatura não inclui /derivatives
        sign_path = "/" + endpoint.lstrip('/')
        if sign_path.startswith("/derivatives"):
            sign_path = sign_path.replace("/derivatives", "", 1)

        # A mensagem é a concatenação de query_string, nonce e o path do endpoint
        message = query_string + nonce + sign_path
        
        # Hash da mensagem com SHA256
        sha256_hash = hashlib.sha256(message.encode()).digest()
        
        # Assinatura com HMAC-SHA512 usando a chave secreta em base64
        hmac_digest = hmac.new(self._api_secret_bytes, sha256_hash, hashlib.sha512).digest()
        
        # A assinatura final é o resultado em base64
        return base64.b64encode(hmac_digest).decode()

    def _make_private_request(self, endpoint: str, payload: Optional[Dict[str, Any]] = None, method: str = "GET") -> Dict[str, Any]:
        """Faz requisição privada para Kraken Futures."""

        payload = payload or {}
        endpoint = endpoint.lstrip('/')
        
        nonce = str(int(time.time() * 1000))
        
        is_post = method.upper() == "POST"
        
        # Para POST, o payload vai no body. Para GET, na query string.
        if is_post:
            query_params = {}
            body_payload = payload
            url = f"{self.base_url.rstrip('/')}/{endpoint}"
        else:
            query_params = payload
            body_payload = {}
            # Adiciona o nonce aos parâmetros da query
            query_params['nonce'] = nonce
            url = f"{self.base_url.rstrip('/')}/{endpoint}?{urlencode(query_params)}"


        # A assinatura é sempre sobre os parâmetros da query
        signature = self._compute_signature(endpoint, nonce, query_params)

        headers = {
            "APIKey": self.api_key,
            "Authent": signature,
        }

        try:
            if is_post:
                # Para POST, o nonce vai no body junto com o resto do payload
                body_payload['nonce'] = nonce
                response = requests.post(url, headers=headers, data=body_payload, timeout=10)
            else:
                response = requests.get(url, headers=headers, timeout=10)

            response.raise_for_status()
            return response.json()

        except requests.exceptions.RequestException as e:
            self.logger.error(f"Erro na requisição privada {endpoint}: {str(e)}")
            raise

    # ---------- Testes públicos ---------- #

    def test_server_time(self) -> Dict[str, Any]:
        """Testa sincronismo via endpoint de tickers."""

        self.logger.info("Testando server time (tickers)...")

        try:
            result = self._make_public_request("tickers")

            if result.get('result') != 'success':
                return {
                    'success': False,
                    'error': result.get('error', 'Resultado inesperado'),
                    'endpoint': 'tickers'
                }

            server_time = result.get('serverTime')
            return {
                'success': True,
                'server_time': server_time,
                'symbols_returned': len(result.get('tickers', [])),
                'endpoint': 'tickers'
            }

        except Exception as e:
            return {
                'success': False,
                'error': str(e),
                'endpoint': 'tickers'
            }

    def test_instruments(self) -> Dict[str, Any]:
        """Testa lista de instrumentos Futures."""

        self.logger.info("Testando instruments...")

        try:
            result = self._make_public_request("instruments")

            if result.get('result') != 'success':
                return {
                    'success': False,
                    'error': result.get('error', 'Resultado inesperado'),
                    'endpoint': 'instruments'
                }

            instruments = result.get('instruments', [])
            btc_contracts = [instr for instr in instruments if 'btc' in instr.get('symbol', '').lower()]

            return {
                'success': True,
                'total_instruments': len(instruments),
                'btc_contracts': [instr.get('symbol') for instr in btc_contracts[:3]],
                'endpoint': 'instruments'
            }

        except Exception as e:
            return {
                'success': False,
                'error': str(e),
                'endpoint': 'instruments'
            }

    def test_ticker_data(self, symbol: str = "pi_xbtusd") -> Dict[str, Any]:
        """Testa ticker específico do Futures."""

        self.logger.info(f"Testando ticker para {symbol}...")

        try:
            result = self._make_public_request("tickers", {"symbol": symbol})

            if result.get('result') != 'success':
                return {
                    'success': False,
                    'error': result.get('error', 'Resultado inesperado'),
                    'endpoint': 'tickers',
                    'symbol': symbol
                }

            tickers = result.get('tickers', [])
            if tickers:
                ticker = tickers[0]
                return {
                    'success': True,
                    'symbol': symbol,
                    'last': ticker.get('last'),
                    'bid': ticker.get('bid'),
                    'ask': ticker.get('ask'),
                    'volume': ticker.get('volume'),
                    'endpoint': 'tickers'
                }

            return {
                'success': False,
                'error': 'Ticker vazio',
                'endpoint': 'tickers',
                'symbol': symbol
            }

        except Exception as e:
            return {
                'success': False,
                'error': str(e),
                'endpoint': 'tickers',
                'symbol': symbol
            }

    # ---------- Testes privados ---------- #

    def test_account_information(self) -> Dict[str, Any]:
        """Testa endpoint de contas Futures."""

        self.logger.info("Testando account information...")

        try:
            result = self._make_private_request("accounts")

            if result.get('result') != 'success':
                return {
                    'success': False,
                    'error': result.get('error', 'Resultado inesperado'),
                    'endpoint': 'accounts'
                }

            accounts = result.get('accounts', [])
            return {
                'success': True,
                'accounts': accounts,
                'accounts_count': len(accounts),
                'endpoint': 'accounts'
            }

        except Exception as e:
            return {
                'success': False,
                'error': str(e),
                'endpoint': 'accounts'
            }

    def test_open_positions(self) -> Dict[str, Any]:
        """Testa endpoint de posições abertas Futures."""

        self.logger.info("Testando openpositions...")

        try:
            result = self._make_private_request("openpositions")

            if result.get('result') != 'success':
                return {
                    'success': False,
                    'error': result.get('error', 'Resultado inesperado'),
                    'endpoint': 'openpositions'
                }

            positions = result.get('openPositions', [])
            return {
                'success': True,
                'positions_count': len(positions),
                'endpoint': 'openpositions'
            }

        except Exception as e:
            return {
                'success': False,
                'error': str(e),
                'endpoint': 'openpositions'
            }

    def test_open_orders(self) -> Dict[str, Any]:
        """Testa endpoint de ordens abertas Futures."""

        self.logger.info("Testando openorders...")

        try:
            result = self._make_private_request("openorders")

            if result.get('result') != 'success':
                return {
                    'success': False,
                    'error': result.get('error', 'Resultado inesperado'),
                    'endpoint': 'openorders'
                }

            orders = result.get('openOrders', [])
            return {
                'success': True,
                'orders_count': len(orders),
                'endpoint': 'openorders'
            }

        except Exception as e:
            return {
                'success': False,
                'error': str(e),
                'endpoint': 'openorders'
            }

    # ---------- Execução principal ---------- #

    def run_comprehensive_test(self) -> Dict[str, Any]:
        """Executa teste abrangente da API Kraken Futures."""

        self.logger.info("Iniciando teste abrangente Kraken Futures...")

        results = {}

        # Testes públicos
        results['server_time'] = self.test_server_time()
        results['instruments'] = self.test_instruments()
        results['ticker_pi_xbtusd'] = self.test_ticker_data("pi_xbtusd")

        # Testes privados
        results['accounts'] = self.test_account_information()
        results['open_positions'] = self.test_open_positions()
        results['open_orders'] = self.test_open_orders()

        successful_tests = sum(1 for result in results.values() if result.get('success', False))
        total_tests = len(results)
        success_rate = (successful_tests / total_tests) * 100 if total_tests else 0

        return {
            'exchange': 'Kraken Futures',
            'environment': self.credentials.kraken.environment,
            'total_tests': total_tests,
            'successful_tests': successful_tests,
            'success_rate': success_rate,
            'results': results,
            'overall_success': success_rate >= 80
        }


def main():
    """Teste principal Kraken Futures"""

    logging.basicConfig(level=logging.INFO)

    parser = argparse.ArgumentParser(description="Kraken Futures endpoint integration test")
    parser.add_argument("--env-file", dest="env_file", help="Arquivo .env com credenciais demo", default=None)
    args = parser.parse_args()

    print("🏦 WOW Capital - Kraken Futures API Test")
    print("=" * 50)

    try:
        cred_manager = CredentialsManager(env_file=args.env_file)
        credentials = cred_manager.load_credentials()

        if not credentials.kraken:
            print("❌ Credenciais Kraken não disponíveis")
            return False

        tester = KrakenAPITester(cred_manager)
        results = tester.run_comprehensive_test()

        print(f"\n📊 Resultados Kraken Futures ({results['environment']}):")
        print(f"   Testes: {results['successful_tests']}/{results['total_tests']} ({results['success_rate']:.1f}%)")

        print("\n📋 Detalhes dos Testes:")
        for test_name, test_result in results['results'].items():
            status = "✅" if test_result.get('success', False) else "❌"
            endpoint = test_result.get('endpoint', test_name)
            error = test_result.get('error', '')

            print(f"   {status} {test_name.replace('_', ' ').title()} ({endpoint})")
            if error and not test_result.get('success', False):
                print(f"      Error: {error}")

            if test_name == 'ticker_pi_xbtusd' and test_result.get('success'):
                print(f"      Último preço: {test_result.get('last', 'N/A')}")

        if results['overall_success']:
            print("\n🎉 Kraken Futures API funcionando corretamente!")
        else:
            print("\n⚠️  Alguns endpoints Kraken Futures precisam de atenção")

        return results['overall_success']

    except Exception as e:  # pragma: no cover - saída informativa
        print(f"❌ Erro geral: {str(e)}")
        import traceback
        traceback.print_exc()
        return False


if __name__ == "__main__":
    success = main()
    sys.exit(0 if success else 1)
