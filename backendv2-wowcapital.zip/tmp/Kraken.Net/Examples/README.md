# Examples

### Kraken.Examples.Api
A minimal API showing how to integrate Kraken.Net in a web API project

### Kraken.Examples.Console
A simple console client demonstrating basic usage

### Kraken.Examples.OrderBook
Example of using the client side order book implementation

### Kraken.Examples.Tracker
Example of using the trade tracker