﻿namespace Kraken.Net.ExtensionMethods
{
    /// <summary>
    /// Extension methods specific to using the Kraken API
    /// </summary>
    public static class KrakenExtensionMethods
    {
    }
}
